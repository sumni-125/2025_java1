package day14.teamproject;

public interface Order {

	String Order();
	int cost();

	
}
